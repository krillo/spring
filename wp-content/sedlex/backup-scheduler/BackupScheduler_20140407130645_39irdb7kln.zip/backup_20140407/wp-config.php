<?php
/**
 * Baskonfiguration för WordPress.
 *
 * Denna fil innehåller följande konfigurationer: Inställningar för MySQL,
 * Tabellprefix, Säkerhetsnycklar, WordPress-språk, och ABSPATH.
 * Mer information på {@link http://codex.wordpress.org/Editing_wp-config.php 
 * Editing wp-config.php}. MySQL-uppgifter får du från ditt webbhotell.
 *
 * Denna fil används av wp-config.php-genereringsskript under installationen.
 * Du behöver inte använda webbplatsen, du kan kopiera denna fil direkt till
 * "wp-config.php" och fylla i värdena.
 *
 * @package WordPress
 */

// ** MySQL-inställningar - MySQL-uppgifter får du från ditt webbhotell ** //
/** Namnet på databasen du vill använda för WordPress */
define('DB_NAME', 'spring');
define('DB_USER', 'reptilo');
define('DB_PASSWORD', 'reptilo');
define('DB_HOST', 'localhost');
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', '');

/**#@+
 * Unika autentiseringsnycklar och salter.
 *
 * Ändra dessa till unika fraser!
 * Du kan generera nycklar med {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * Du kan när som helst ändra dessa nycklar för att göra aktiva cookies obrukbara, vilket tvingar alla användare att logga in på nytt.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'hm![s[N};VJK^ 4?R++R]*N9;iTZ!l,p|Ex[4^})[X?8&AF}am=I^ukV`La=Bn#R');
define('SECURE_AUTH_KEY',  '*/<0Ge_<xX*KdN>/M-K4I+ N0zBjoWCNoP}ADnBH[S]Q&>l dJ|(oT=;2!^~(W?}');
define('LOGGED_IN_KEY',    '1yTIFJ9C8,&K^p(R<$?i; BNMtb^m r>;m+W+3x%NP Ns=O%LzV>?J~AGe;c2XnC');
define('NONCE_KEY',        '=[+P_xn~H}y:4-Aw`)l4-vhb),+-^/b%0A[o{-@UoP+|188F+<$|P`c`L#?|).)B');
define('AUTH_SALT',        'Gj^_AI1Yyh_#tvyb=T5TF.+8i?N.kwr4oWbg$M`YRYBBS<X#WQy{V6h/v,3qf8ka');
define('SECURE_AUTH_SALT', '6ZI@4jlL5:z5wb;^bG{|@~o!/}Ospv(6M$-Ho|<pvwOa~*ua&RN9w@K*EFyUZmLP');
define('LOGGED_IN_SALT',   '$lrW+VQ~vU9=S;Wh^~SfX~31&;^veNvEd0-iEq0YtKEo%Lk,Lr+4VrFyl,m`5p>4');
define('NONCE_SALT',       'RSt:P> MVpv:J~iQL5|Ml[-}o{w12[TH9{1<cGr#}/h#V|tB7C=C9|h--3oyC0qP');

/**#@-*/

/**
 * Tabellprefix för WordPress Databasen.
 *
 * Du kan ha flera installationer i samma databas om du ger varje installation ett unikt
 * prefix. Endast siffror, bokstäver och understreck!
 */
$table_prefix  = 'wp_';

/**
 * WordPress-språk, förinställt för svenska.
 *
 * Du kan ändra detta för att ändra språk för WordPress.  En motsvarande .mo-fil
 * för det valda språket måste finnas i wp-content/languages. Exempel, lägg till
 * sv_SE.mo i wp-content/languages och ange WPLANG till 'sv_SE' för att få sidan
 * på svenska.
 */
define('WPLANG', 'sv_SE');

/** 
 * För utvecklare: WordPress felsökningsläge. 
 * 
 * Ändra detta till true för att aktivera meddelanden under utveckling. 
 * Det är rekommderat att man som tilläggsskapare och temaskapare använder WP_DEBUG 
 * i sin utvecklingsmiljö. 
 */ 
define( 'WP_DEBUG', false );
//define( 'WP_DEBUG', true );
//define( 'WP_DEBUG_LOG', true ); // Stored in wp-content/debug.log
//define( 'WP_DEBUG_DISPLAY', false );

/* Det var allt, sluta redigera här! Blogga på. */

/** Absoluta sökväg till WordPress-katalogen. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Anger WordPress-värden och inkluderade filer. */
require_once(ABSPATH . 'wp-settings.php');